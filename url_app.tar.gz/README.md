<img src="https://github.com/kura-labs-org/kuralabs_deployment_1/blob/main/Kuralogo.png">
<h1 align="center">kuralabs_deployment_5<h1> 
  
Demonstrate your ability to deploy a containerized application.

## Deployment Document Link:
- Link to instructions: https://github.com/kura-labs-org/kuralabs_deployment_5/blob/main/Deployment-5_Assignment.pdf
